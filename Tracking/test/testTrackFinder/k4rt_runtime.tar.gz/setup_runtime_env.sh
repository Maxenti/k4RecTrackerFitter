#!/usr/bin/env bash
set -euo pipefail
echo "[setup] CWD=$(pwd)"
[[ -d Tracking ]] || { echo "[error] Tracking/ not present after unpack"; exit 2; }
export GAUDI_PLUGIN_PATH="$PWD:$PWD/Tracking:$PWD/DCHdigi:$PWD/ARCdigi:$PWD/VTXdigi:${GAUDI_PLUGIN_PATH:-}"
export LD_LIBRARY_PATH="$PWD/Tracking:$PWD/DCHdigi:$PWD/ARCdigi:$PWD/VTXdigi:${LD_LIBRARY_PATH:-}"
export PYTHONPATH="$PWD/python:${PYTHONPATH:-}"
echo "[env] GAUDI_PLUGIN_PATH=${GAUDI_PLUGIN_PATH}"
echo "[env] LD_LIBRARY_PATH=${LD_LIBRARY_PATH}"
echo "[env] PYTHONPATH=${PYTHONPATH}"
